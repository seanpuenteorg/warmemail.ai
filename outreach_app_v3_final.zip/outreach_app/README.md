# OutreachAI

AI-powered cold email platform. Runs locally in your browser. Free to use — you only pay for your own API usage.

Built for agency owners and developers who want personalised, AI-written outreach at scale without paying for overpriced SaaS tools.

---

## What it does

- **Writes personalised emails** using Claude AI — scrapes each prospect's website for context automatically
- **A/B tests subject lines** — two variants per email, randomly assigned
- **Sends via your own email** (Gmail, Outlook, or any SMTP) — no third-party sending service needed
- **Syncs with your CRM** — pull leads from Close, HubSpot, or GoHighLevel. Logs sent emails and creates follow-up tasks automatically
- **Live send dashboard** — watch emails send in real time with a progress feed

---

## Setup

### Requirements
- Python 3.9+
- An [Anthropic API key](https://console.anthropic.com)
- A Gmail or Outlook email account

### Install

```bash
git clone https://github.com/yourname/outreachai
cd outreachai
pip3 install -r requirements.txt
python3 app.py
```

Browser opens automatically at `http://127.0.0.1:5000`

> If the browser does not open, go to `http://127.0.0.1:5000` manually. Do not use `localhost:5000`

---

## Configuration

### 1. Setup tab
- **Anthropic API key** — from [console.anthropic.com](https://console.anthropic.com)
- **Your name and company** — appears in every email sign-off
- **SMTP credentials** — your email account for sending

**Gmail:**
- Host: `smtp.gmail.com` · Port: `587`
- Password: Generate an [App Password](https://myaccount.google.com/apppasswords)

**Outlook / Office 365:**
- Host: `smtp.office365.com` · Port: `587`
- Password: Your regular Outlook password

**ICP, angle, and tone** — describe your target customer and pain point in plain English. Claude uses this to write every email.

### 2. Integrations tab (optional)
Connect Close CRM, HubSpot, or GoHighLevel to:
- Pull contacts directly — no CSV needed
- Auto-log sent emails to the contact record
- Create follow-up tasks 4 days after each send

### 3. Leads tab
Import a CSV or sync from your connected CRM.

CSV columns: `Company, First Name, Last Name, Email, Phone, URL, custom.Category, custom.Region`

### 4. Preview tab
Generate 5 sample emails before sending. Review and approve.

### 5. Send tab
Hit **Start Campaign**. Emails send with a 5-second delay between each. Stop anytime.

---

## Daily workflow

```bash
cd outreachai
python3 app.py
```

Then: Preview → approve → Send. The app remembers who has been sent to across sessions.

---

## Sending limits

Start conservative to protect your domain reputation:

| Day | Limit |
|-----|-------|
| 1–3 | 50/day |
| 4–7 | 75/day |
| 8+  | 100/day |

---

## Cost

The only cost is your Anthropic API usage. At current rates, generating 100 personalised emails costs roughly **$0.10–0.20**.

Sending is free via your own SMTP account.

---

## Stack

- **Backend** — Python / Flask
- **AI** — Claude (Anthropic API)
- **Email** — SMTP (your account)
- **CRM** — Close, HubSpot, GoHighLevel APIs
- **Frontend** — Vanilla HTML/CSS/JS
- **Database** — SQLite (local file)

---

## License

MIT — free to use, modify, and distribute.
