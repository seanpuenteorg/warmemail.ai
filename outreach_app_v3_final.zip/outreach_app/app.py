"""
OutreachAI v3 — AI-powered cold email platform
Run: python3 app.py
Then open: http://127.0.0.1:5000
"""

import csv, json, os, time, random, sqlite3, smtplib, threading, webbrowser, logging
from io import StringIO
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import Flask, request, jsonify, render_template
import requests
from bs4 import BeautifulSoup

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger(__name__)

app = Flask(__name__)
DB_PATH = "outreach.db"

# ── Database ──────────────────────────────────────────────────────────────────
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS leads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT, last_name TEXT, email TEXT UNIQUE,
        company TEXT, phone TEXT, url TEXT, category TEXT, region TEXT,
        crm_id TEXT, crm_source TEXT,
        status TEXT DEFAULT 'pending',
        subject TEXT, body TEXT, website_context TEXT,
        sent_at TEXT, opened_at TEXT, replied_at TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("""CREATE TABLE IF NOT EXISTS activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT, message TEXT, email TEXT, meta TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    conn.commit()
    conn.close()

def get_setting(key, default=""):
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row[0] if row else default

def set_setting(key, value):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))
    conn.commit()
    conn.close()

def log_activity(type_, message, email="", meta=None):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO activity (type, message, email, meta) VALUES (?,?,?,?)",
        (type_, message, email, json.dumps(meta) if meta else None))
    conn.commit()
    conn.close()

# ── Website scraper ───────────────────────────────────────────────────────────
def scrape_website(url):
    if not url or not url.startswith("http"):
        return ""
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"}
        r = requests.get(url, headers=headers, timeout=8, allow_redirects=True)
        if not r.ok:
            return ""
        soup = BeautifulSoup(r.text, "html.parser")
        for tag in soup(["script","style","nav","footer","header"]):
            tag.decompose()
        parts = []
        title = soup.find("title")
        if title: parts.append(title.get_text(strip=True))
        for h in soup.find_all(["h1","h2"])[:6]:
            t = h.get_text(strip=True)
            if t and len(t) > 3: parts.append(t)
        meta = soup.find("meta", attrs={"name": "description"})
        if meta and meta.get("content"): parts.append(meta["content"][:200])
        for p in soup.find_all("p")[:4]:
            t = p.get_text(strip=True)
            if len(t) > 40: parts.append(t[:200])
        return " | ".join(parts)[:1000]
    except:
        return ""

# ── Claude email generator ────────────────────────────────────────────────────
def build_system_prompt(icp, angle, tone):
    return f"""You write cold outreach emails based on the following configuration:

ICP (Ideal Customer Profile): {icp}
Core angle/pain point: {angle}
Tone: {tone}

VOICE RULES:
- Short sentences. No fluff. Under 100 words for the body.
- Conversational, sounds human — not a campaign.
- Never use: "I hope this finds you well", "I wanted to reach out", "synergy", "solutions", "cutting-edge"
- One idea per email. Don't stack multiple angles.
- CTA is always a single soft question like "Worth a quick 15-minute call this week?"
- Sign off with sender's name and company name

PERSONALISATION:
- Use their first name naturally
- If website context is provided, reference ONE specific detail subtly
- Don't make it obvious you scraped their site

STRUCTURE: Hook (pain/stat) > Bridge (connect pain to fix) > Credibility (who you are) > CTA

SUBJECT LINE: 4-6 words, lowercase, curiosity-driven or pain-specific

OUTPUT: valid JSON only, no markdown:
{{"subject_a": "first subject variant", "subject_b": "second subject variant", "body": "email body"}}"""

def gen_email(first, company, region, url_context, api_key, icp, angle, tone, sender_name, sender_company):
    system = build_system_prompt(icp, angle, tone)
    context_note = f"\nWebsite context: {url_context}" if url_context else ""
    prompt = f"Write cold email.\nFirst name: {first}\nCompany: {company}\nRegion: {region}\nSender: {sender_name} at {sender_company}{context_note}"
    r = requests.post("https://api.anthropic.com/v1/messages",
        headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json={"model": "claude-sonnet-4-20250514", "max_tokens": 600, "system": system,
              "messages": [{"role": "user", "content": prompt}]},
        timeout=30)
    r.raise_for_status()
    text = r.json()["content"][0]["text"].strip().replace("```json","").replace("```","").strip()
    return json.loads(text)

# ── Email sender ──────────────────────────────────────────────────────────────
def send_smtp(to_email, subject, body, from_email, smtp_host, smtp_port, smtp_user, smtp_pass):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = to_email
    msg.attach(MIMEText(body, "plain"))
    with smtplib.SMTP(smtp_host, int(smtp_port)) as server:
        server.starttls()
        server.login(smtp_user, smtp_pass)
        server.sendmail(from_email, to_email, msg.as_string())

# ── CRM: Close ────────────────────────────────────────────────────────────────
def close_test_connection(api_key):
    r = requests.get("https://api.close.com/api/v1/me/", auth=(api_key, ""), timeout=10)
    return r.ok

def close_pull_leads(api_key, limit=200):
    leads = []
    has_more = True
    skip = 0
    while has_more and len(leads) < limit:
        r = requests.get(f"https://api.close.com/api/v1/lead/?_limit=100&_skip={skip}",
            auth=(api_key, ""), timeout=15)
        if not r.ok: break
        data = r.json()
        for lead in data.get("data", []):
            for contact in lead.get("contacts", []):
                for em in contact.get("emails", []):
                    email = em.get("email", "").strip()
                    if not email: continue
                    name = contact.get("name", "").strip().split(" ", 1)
                    leads.append({
                        "first_name": name[0] if name else "",
                        "last_name": name[1] if len(name) > 1 else "",
                        "email": email,
                        "company": lead.get("display_name", ""),
                        "phone": contact.get("phones", [{}])[0].get("phone", "") if contact.get("phones") else "",
                        "url": lead.get("url", ""),
                        "crm_id": lead.get("id", ""),
                        "crm_source": "close"
                    })
        has_more = data.get("has_more", False)
        skip += 100
    return leads

def close_log_email(api_key, lead_crm_id, to_email, from_email, subject, body):
    payload = {"lead_id": lead_crm_id, "status": "sent", "direction": "outbound",
               "subject": subject, "body_text": body, "to": [to_email], "from": from_email}
    r = requests.post("https://api.close.com/api/v1/activity/email/",
        auth=(api_key, ""), json=payload, timeout=10)
    return r.ok

def close_create_task(api_key, lead_crm_id, text, due_days=4):
    due = (datetime.utcnow() + timedelta(days=due_days)).strftime("%Y-%m-%dT%H:%M:%S.000000+00:00")
    r = requests.post("https://api.close.com/api/v1/task/",
        auth=(api_key, ""), json={"lead_id": lead_crm_id, "text": text, "due_date": due, "_type": "lead"}, timeout=10)
    return r.ok

# ── CRM: HubSpot ──────────────────────────────────────────────────────────────
def hubspot_test_connection(api_key):
    r = requests.get("https://api.hubapi.com/crm/v3/objects/contacts?limit=1",
        headers={"Authorization": f"Bearer {api_key}"}, timeout=10)
    return r.ok

def hubspot_pull_leads(api_key, limit=200):
    leads = []
    after = None
    while len(leads) < limit:
        params = {"limit": 100, "properties": "firstname,lastname,email,phone,company,website"}
        if after: params["after"] = after
        r = requests.get("https://api.hubapi.com/crm/v3/objects/contacts",
            headers={"Authorization": f"Bearer {api_key}"}, params=params, timeout=15)
        if not r.ok: break
        data = r.json()
        for c in data.get("results", []):
            props = c.get("properties", {})
            email = props.get("email", "").strip()
            if not email: continue
            leads.append({
                "first_name": props.get("firstname", ""), "last_name": props.get("lastname", ""),
                "email": email, "company": props.get("company", ""),
                "phone": props.get("phone", ""), "url": props.get("website", ""),
                "crm_id": c.get("id", ""), "crm_source": "hubspot"
            })
        after = data.get("paging", {}).get("next", {}).get("after")
        if not after: break
    return leads

def hubspot_log_email(api_key, contact_crm_id, to_email, from_email, subject, body):
    payload = {
        "engagement": {"active": True, "type": "EMAIL"},
        "associations": {"contactIds": [int(contact_crm_id)]},
        "metadata": {"from": {"email": from_email}, "to": [{"email": to_email}],
                     "subject": subject, "text": body}
    }
    r = requests.post("https://api.hubapi.com/engagements/v1/engagements",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json=payload, timeout=10)
    return r.ok

def hubspot_create_task(api_key, contact_crm_id, text, due_days=4):
    due_ts = int((datetime.utcnow() + timedelta(days=due_days)).timestamp() * 1000)
    payload = {
        "engagement": {"active": True, "type": "TASK"},
        "associations": {"contactIds": [int(contact_crm_id)]},
        "metadata": {"body": text, "status": "NOT_STARTED", "forObjectType": "CONTACT"},
        "timestamp": due_ts
    }
    r = requests.post("https://api.hubapi.com/engagements/v1/engagements",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json=payload, timeout=10)
    return r.ok

# ── CRM: GoHighLevel ──────────────────────────────────────────────────────────
def ghl_test_connection(api_key):
    r = requests.get("https://services.leadconnectorhq.com/contacts/?limit=1",
        headers={"Authorization": f"Bearer {api_key}", "Version": "2021-07-28"}, timeout=10)
    return r.ok

def ghl_pull_leads(api_key, limit=200):
    leads = []
    page = 1
    while len(leads) < limit:
        r = requests.get("https://services.leadconnectorhq.com/contacts/",
            headers={"Authorization": f"Bearer {api_key}", "Version": "2021-07-28"},
            params={"limit": 100, "page": page}, timeout=15)
        if not r.ok: break
        contacts = r.json().get("contacts", [])
        if not contacts: break
        for c in contacts:
            email = (c.get("email") or "").strip()
            if not email: continue
            leads.append({
                "first_name": c.get("firstName", ""), "last_name": c.get("lastName", ""),
                "email": email, "company": c.get("companyName", ""),
                "phone": c.get("phone", ""), "url": c.get("website", ""),
                "crm_id": c.get("id", ""), "crm_source": "ghl"
            })
        if len(contacts) < 100: break
        page += 1
    return leads

def ghl_log_email(api_key, contact_crm_id, subject, body):
    payload = {"contactId": contact_crm_id, "body": f"Email sent\nSubject: {subject}\n\n{body}"}
    r = requests.post("https://services.leadconnectorhq.com/contacts/notes",
        headers={"Authorization": f"Bearer {api_key}", "Version": "2021-07-28",
                 "Content-Type": "application/json"}, json=payload, timeout=10)
    return r.ok

def ghl_create_task(api_key, contact_crm_id, text, due_days=4):
    due = (datetime.utcnow() + timedelta(days=due_days)).strftime("%Y-%m-%dT%H:%M:%S+00:00")
    r = requests.post("https://services.leadconnectorhq.com/contacts/tasks",
        headers={"Authorization": f"Bearer {api_key}", "Version": "2021-07-28",
                 "Content-Type": "application/json"},
        json={"contactId": contact_crm_id, "title": text, "dueDate": due, "status": "incompleted"}, timeout=10)
    return r.ok

# ── CRM dispatch helpers ──────────────────────────────────────────────────────
def crm_log_email(lead_crm_id, crm_source, to_email, from_email, subject, body):
    if not lead_crm_id or not crm_source: return
    key = get_setting(f"{crm_source}_key")
    if not key: return
    try:
        if crm_source == "close": close_log_email(key, lead_crm_id, to_email, from_email, subject, body)
        elif crm_source == "hubspot": hubspot_log_email(key, lead_crm_id, to_email, from_email, subject, body)
        elif crm_source == "ghl": ghl_log_email(key, lead_crm_id, subject, body)
    except Exception as e:
        log.warning(f"CRM log email failed ({crm_source}): {e}")

def crm_create_task(lead_crm_id, crm_source, subject):
    if not lead_crm_id or not crm_source: return
    key = get_setting(f"{crm_source}_key")
    if not key: return
    try:
        text = f"Follow up on email: {subject}"
        if crm_source == "close": close_create_task(key, lead_crm_id, text)
        elif crm_source == "hubspot": hubspot_create_task(key, lead_crm_id, text)
        elif crm_source == "ghl": ghl_create_task(key, lead_crm_id, text)
    except Exception as e:
        log.warning(f"CRM create task failed ({crm_source}): {e}")

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/settings", methods=["GET"])
def get_settings():
    keys = ["anthropic_key","from_email","sender_name","sender_company",
            "smtp_host","smtp_port","smtp_user","smtp_pass",
            "icp","angle","tone","daily_limit",
            "close_key","close_enabled","hubspot_key","hubspot_enabled","ghl_key","ghl_enabled"]
    return jsonify({k: get_setting(k) for k in keys})

@app.route("/api/settings", methods=["POST"])
def save_settings():
    for k, v in request.json.items():
        set_setting(k, v)
    return jsonify({"ok": True})

@app.route("/api/stats")
def get_stats():
    conn = sqlite3.connect(DB_PATH)
    total   = conn.execute("SELECT COUNT(*) FROM leads").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM leads WHERE status='pending'").fetchone()[0]
    sent    = conn.execute("SELECT COUNT(*) FROM leads WHERE status='sent'").fetchone()[0]
    opened  = conn.execute("SELECT COUNT(*) FROM leads WHERE opened_at IS NOT NULL").fetchone()[0]
    daily = []
    for i in range(6, -1, -1):
        day = (datetime.utcnow() - timedelta(days=i)).strftime("%Y-%m-%d")
        count = conn.execute("SELECT COUNT(*) FROM leads WHERE sent_at LIKE ?", (f"{day}%",)).fetchone()[0]
        daily.append({"date": day, "count": count})
    recent = conn.execute("SELECT type, message, email, created_at FROM activity ORDER BY created_at DESC LIMIT 10").fetchall()
    conn.close()
    return jsonify({
        "total": total, "pending": pending, "sent": sent, "opened": opened,
        "daily": daily,
        "recent": [{"type": r[0], "message": r[1], "email": r[2], "time": r[3]} for r in recent]
    })

@app.route("/api/leads")
def get_leads():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("""SELECT id, first_name, last_name, email, company,
        region, category, status, subject, sent_at, crm_source FROM leads
        ORDER BY created_at DESC LIMIT 200""").fetchall()
    conn.close()
    return jsonify([{"id":r[0],"first_name":r[1],"last_name":r[2],"email":r[3],
        "company":r[4],"region":r[5],"category":r[6],"status":r[7],
        "subject":r[8],"sent_at":r[9],"crm_source":r[10]} for r in rows])

@app.route("/api/import", methods=["POST"])
def import_leads():
    file = request.files.get("file")
    if not file: return jsonify({"error": "No file"}), 400
    content = file.read().decode("utf-8-sig")
    reader = csv.DictReader(StringIO(content))
    conn = sqlite3.connect(DB_PATH)
    added = skipped = 0
    for row in reader:
        email = row.get("Email","").strip()
        if not email: continue
        try:
            conn.execute("""INSERT OR IGNORE INTO leads
                (first_name,last_name,email,company,phone,url,category,region)
                VALUES (?,?,?,?,?,?,?,?)""",
                (row.get("First Name","").strip(), row.get("Last Name","").strip(), email,
                 row.get("Company","").strip(), row.get("Phone","").strip(),
                 row.get("URL","").strip(), row.get("custom.Category","").strip(),
                 row.get("custom.Region","").strip()))
            added += 1
        except: skipped += 1
    conn.commit(); conn.close()
    log_activity("import", f"Imported {added} leads from CSV")
    return jsonify({"added": added, "skipped": skipped})

@app.route("/api/leads/clear", methods=["POST"])
def clear_leads():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("DELETE FROM leads"); conn.commit(); conn.close()
    log_activity("clear", "All leads cleared")
    return jsonify({"ok": True})

@app.route("/api/crm/test", methods=["POST"])
def crm_test():
    data = request.json
    crm, key = data.get("crm"), data.get("key","").strip()
    if not key: return jsonify({"ok": False, "error": "No API key provided"})
    try:
        if crm == "close": ok = close_test_connection(key)
        elif crm == "hubspot": ok = hubspot_test_connection(key)
        elif crm == "ghl": ok = ghl_test_connection(key)
        else: return jsonify({"ok": False, "error": "Unknown CRM"})
        return jsonify({"ok": ok, "error": "" if ok else "Connection failed — check your API key"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/crm/sync", methods=["POST"])
def crm_sync():
    crm = request.json.get("crm")
    key = get_setting(f"{crm}_key")
    if not key: return jsonify({"error": "No API key saved"}), 400
    try:
        if crm == "close": leads = close_pull_leads(key)
        elif crm == "hubspot": leads = hubspot_pull_leads(key)
        elif crm == "ghl": leads = ghl_pull_leads(key)
        else: return jsonify({"error": "Unknown CRM"}), 400
        conn = sqlite3.connect(DB_PATH)
        added = skipped = 0
        for lead in leads:
            try:
                conn.execute("""INSERT OR IGNORE INTO leads
                    (first_name,last_name,email,company,phone,url,crm_id,crm_source)
                    VALUES (?,?,?,?,?,?,?,?)""",
                    (lead["first_name"], lead["last_name"], lead["email"], lead["company"],
                     lead["phone"], lead["url"], lead["crm_id"], lead["crm_source"]))
                added += 1
            except: skipped += 1
        conn.commit(); conn.close()
        log_activity("sync", f"Synced {added} leads from {crm.title()}", meta={"crm": crm})
        return jsonify({"added": added, "skipped": skipped, "total": len(leads)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/preview", methods=["POST"])
def preview():
    api_key = get_setting("anthropic_key")
    if not api_key: return jsonify({"error": "Anthropic API key not set"}), 400
    icp = get_setting("icp","businesses"); angle = get_setting("angle","missed opportunities")
    tone = get_setting("tone","professional"); sender_name = get_setting("sender_name","")
    sender_company = get_setting("sender_company","")
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("SELECT id,first_name,last_name,email,company,url,category,region FROM leads WHERE status='pending' LIMIT 5").fetchall()
    conn.close()
    previews = []
    for r in rows:
        lid, first, last, email, company, url, cat, region = r
        ctx = scrape_website(url) if url else ""
        try:
            content = gen_email(first, company, region, ctx, api_key, icp, angle, tone, sender_name, sender_company)
            previews.append({"id": lid, "first": first, "last": last, "email": email,
                "company": company, "subject_a": content.get("subject_a",""),
                "subject_b": content.get("subject_b",""), "body": content.get("body",""),
                "context": ctx[:100] if ctx else ""})
        except Exception as e:
            previews.append({"id": lid, "email": email, "error": str(e)})
    return jsonify(previews)

send_state = {"running": False, "sent": 0, "errors": 0, "current": "", "log": [], "total": 0}

@app.route("/api/send/start", methods=["POST"])
def start_send():
    if send_state["running"]: return jsonify({"error": "Already running"}), 400
    api_key = get_setting("anthropic_key"); from_email = get_setting("from_email")
    smtp_host = get_setting("smtp_host"); smtp_port = get_setting("smtp_port","587")
    smtp_user = get_setting("smtp_user"); smtp_pass = get_setting("smtp_pass")
    icp = get_setting("icp"); angle = get_setting("angle"); tone = get_setting("tone")
    sender_name = get_setting("sender_name"); sender_company = get_setting("sender_company")
    daily_limit = int(get_setting("daily_limit","50"))
    if not all([api_key, from_email, smtp_host, smtp_user, smtp_pass]):
        return jsonify({"error": "Missing settings — check API keys and SMTP config"}), 400

    def run():
        send_state.update({"running": True, "sent": 0, "errors": 0, "log": []})
        conn = sqlite3.connect(DB_PATH)
        rows = conn.execute("""SELECT id,first_name,last_name,email,company,url,region,crm_id,crm_source
            FROM leads WHERE status='pending' LIMIT ?""", (daily_limit,)).fetchall()
        conn.close()
        send_state["total"] = len(rows)
        for r in rows:
            if not send_state["running"]: break
            lid, first, last, email, company, url, region, crm_id, crm_source = r
            send_state["current"] = f"{first} {last} — {company}"
            try:
                ctx = scrape_website(url) if url else ""
                content = gen_email(first, company, region, ctx, api_key, icp, angle, tone, sender_name, sender_company)
                subject = content.get("subject_a","") if random.random() < 0.5 else content.get("subject_b","")
                body = content.get("body","")
                send_smtp(email, subject, body, from_email, smtp_host, smtp_port, smtp_user, smtp_pass)
                conn2 = sqlite3.connect(DB_PATH)
                conn2.execute("UPDATE leads SET status='sent', subject=?, body=?, website_context=?, sent_at=? WHERE id=?",
                    (subject, body, ctx[:500], datetime.utcnow().isoformat(), lid))
                conn2.commit(); conn2.close()
                crm_log_email(crm_id, crm_source, email, from_email, subject, body)
                crm_create_task(crm_id, crm_source, subject)
                send_state["sent"] += 1
                send_state["log"].append({"status":"sent","email":email,"subject":subject,"time":datetime.utcnow().isoformat()})
                log_activity("sent", f"Sent to {email}", email=email, meta={"subject": subject})
            except Exception as e:
                send_state["errors"] += 1
                send_state["log"].append({"status":"error","email":email,"error":str(e),"time":datetime.utcnow().isoformat()})
                conn3 = sqlite3.connect(DB_PATH)
                conn3.execute("UPDATE leads SET status='error' WHERE id=?", (lid,))
                conn3.commit(); conn3.close()
                log_activity("error", f"Failed: {email}: {str(e)}", email=email)
            time.sleep(5)
        send_state["running"] = False
        send_state["current"] = ""

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"ok": True})

@app.route("/api/send/stop", methods=["POST"])
def stop_send():
    send_state["running"] = False
    return jsonify({"ok": True})

@app.route("/api/send/status")
def send_status():
    return jsonify(send_state)

if __name__ == "__main__":
    init_db()
    print("\n" + "="*50)
    print("  OutreachAI v3")
    print("  Open: http://127.0.0.1:5000")
    print("="*50 + "\n")
    threading.Timer(1.5, lambda: webbrowser.open("http://127.0.0.1:5000")).start()
    app.run(debug=False, port=5000)
